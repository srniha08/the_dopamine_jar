Markdown
# 🧪 The Dopamine Jar (Adulting Simulator)

A sleek, user-friendly, and slightly sarcastic task manager designed to convert your daily chores into satisfying, colorful marble serotonin. No heavy algorithms, no complex sub-menus—just low-friction task tracking with realistic grid-locking physics.

---

## ✨ Features

* **Strict 3×5 Gravity Grid:** Marbles drop straight from the mouth of the jar, bounce realistically, and snap permanently onto the floor of the jar—stacking cleanly from the bottom up.
* **Serotonin Animation Loop:** Clicking a quest checkbox flashes the button into the marble's designated color, triggers a kinetic bounce animation, and drops a matching marble into your container.
* **Overachiever Protection:** The system limits your dashboard to a maximum of 15 pending items to keep your stress levels classroom-safe. 
* **Zero-Cloud Sandbox:** Built entirely using browser `localStorage`. Your data stays in your browser cache—no heavy backend, no data tracking, instant load times.
* **Daily Amnesia Reset:** Automatically clears out yesterday's marbles when a new calendar day arrives so you can start every morning with a fresh slate..

---

## 🛠️ Tech Stack

This project is built completely free of external frameworks or dependencies to maximize speed and simplicity:

* **Frontend Structure:** HTML5
* **Styling & Physics:** CSS3 (Custom Grid Layouts & `@keyframes` Transform Vectors)
* **Logic Engine:** Vanilla JavaScript (ES6 Modules)
* **Database Sandboxing:** Web Storage API (`localStorage`)
